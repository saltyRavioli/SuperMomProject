var express = require('express');
var router = express.Router();

/* GET home page. */
console.log(__dirname+'/../views/index.html')
router.get('/',function(req,res){
  res.sendFile(path.join('/Users/jiayuanli/WebstormProjects/untitled1/views/index.html'));
  //__dirname : It will resolve to your project folder.
});

module.exports = router;